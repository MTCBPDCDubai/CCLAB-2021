#include<stdio.h>
#include"string.h"
int main()
{
	int i;
	char str[20],**ptr;
	int***p;
}

