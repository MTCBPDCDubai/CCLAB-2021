#include<stdio.h>
int main()
{
	int x,y,z;//these are the variables
	/*In the following section we read 3 variables*/
	scanf("%d",&x);
	scanf("%d",&y);
	scanf("%d",&z);
	printf("sum=%d",x+y+z);//Output the sum 
}
