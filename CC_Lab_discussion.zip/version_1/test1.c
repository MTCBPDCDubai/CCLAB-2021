#include<stdio.h>
int main()
{
	
	int i[10][20],j,k;
	int a[20][30]={0};
//	int (*p)[30]=&(a+1);
	int (*b)[10][20]=&i;
//	int *x;
//	int c=(*(*b+1));
	int (*r)[10];
//	int y=*(*b+1)+2;
//	int (((**r)[10])*t)[10];
//	int b[10];
	int (*s)[10];
//	s=&b;
//	r=&s;
//	int*(*r)=&b;
//	int x=*(*(*(a+i)+j)+k);
//	int (*q)[30]=(a+5)[3];
//	p=a;
//	int i;
//	i=(*p)[3][5];
//	(*p)[2]=&a[5];
//	printf("%d %d",i,(*p)[4]);

//	int a[10][10]={0};
//	printf("%d",(*p)[2][3]);
}

