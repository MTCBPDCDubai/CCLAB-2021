#include<stdio.h>
int main()
{
	int varone,vartwo,varthree,varfour;
	char testone, testtwo,testthree;
	float x,y;
	double z;
	testone=testtwo+testthree/(testone*testtwo);
	vartwo=varone*varfour;
	x=x*y+y;

}
