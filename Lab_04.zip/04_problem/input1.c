#include<stdio.h>
int main()
{
	int i;
	int n;
	int sum;
	sum=0;
	n=10;
	for (i=1;i<=n;i++)
	{
		sum=sum+i;
	}

}
