#include<stdio.h>
int main()
{
	int a,b,c;
	int x,y;
}
