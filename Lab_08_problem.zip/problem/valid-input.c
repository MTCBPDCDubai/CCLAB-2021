#include<stdio.h>
int main()
{
	int i,n;
	float j;
	char str[20];
	char name[10][10];
	int*p;
	p=&i;
	scanf("first name=%s second name=%s",str, name[2]);
	scanf("%d",p);
	printf("value=%f",j);
	
}

