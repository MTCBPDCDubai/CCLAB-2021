#include<stdio.h>
int main()
{
	int var1,var2,var3;
	char var4,var5,var6;
}
