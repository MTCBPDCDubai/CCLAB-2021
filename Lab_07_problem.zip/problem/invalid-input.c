#include<stdio.h>
int main()
{
	int i,n=5;
	float j;
	char str[20];
	char name[10][10];
	for(i=0;i<n;i++)
	{
		float n=10.5;
		i=i+n;
	}	
}

