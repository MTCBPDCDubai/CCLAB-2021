#include<stdio.h>
int main()
{
	int i;
	char str[20];
	char name[10][10];
	int prelength;
	for (i=0;i<prelenth;i++)
	{
		str[i]=str[i]+name[i];
	}
}

