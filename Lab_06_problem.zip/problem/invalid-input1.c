#include<stdio.h>
int main()
{
	int i;
	char str[20];
	char name[10][10];
	char*p=name;	
}

