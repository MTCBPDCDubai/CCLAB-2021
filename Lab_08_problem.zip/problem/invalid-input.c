#include<stdio.h>
int main()
{
	int i,n=5;
	float j;
	char str[20];
	char name[10][10];
	scanf("%s",str[0]);
}

