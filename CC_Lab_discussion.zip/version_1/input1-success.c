#include<stdio.h>
int main()
{
	unsigned long int var1,***var2,var3;
	char var4,var5,var6;
	unsigned short char var7,*var8;

	var1=***var2+var3;
	
}
